/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.dolphinscheduler.plugin.alert.wechattalk;

import static org.apache.dolphinscheduler.common.constants.Constants.STRING_FALSE;
import static org.apache.dolphinscheduler.common.constants.Constants.STRING_NO;
import static org.apache.dolphinscheduler.common.constants.Constants.STRING_TRUE;
import static org.apache.dolphinscheduler.common.constants.Constants.STRING_YES;

import org.apache.dolphinscheduler.alert.api.AlertChannel;
import org.apache.dolphinscheduler.alert.api.AlertChannelFactory;
import org.apache.dolphinscheduler.spi.params.PasswordParam;
import org.apache.dolphinscheduler.spi.params.base.ParamsOptions;
import org.apache.dolphinscheduler.spi.params.base.PluginParams;
import org.apache.dolphinscheduler.spi.params.base.Validate;
import org.apache.dolphinscheduler.spi.params.input.InputParam;
import org.apache.dolphinscheduler.spi.params.radio.RadioParam;

import java.util.Arrays;
import java.util.List;

import com.google.auto.service.AutoService;

@AutoService(AlertChannelFactory.class)
public final class WechatTalkAlertChannelFactory implements AlertChannelFactory {

    @Override
    public String name() {
        return "WechatTalk";
    }

    @Override
    public List<PluginParams> params() {
        InputParam webHookParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_WEB_HOOK,
                        WechatTalkParamsConstants.WECHAT_TALK_WEB_HOOK)
                .addValidate(Validate.newBuilder()
                        .setRequired(true)
                        .build())
                .build();
        InputParam keywordParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_KEYWORD,
                        WechatTalkParamsConstants.WECHAT_TALK_KEYWORD)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();

        InputParam secretParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_SECRET,
                        WechatTalkParamsConstants.WECHAT_TALK_SECRET)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();

        RadioParam msgTypeParam = RadioParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_MSG_TYPE,
                        WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE)
                .addParamsOptions(new ParamsOptions(WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE_TEXT,
                        WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE_TEXT, false))
                .addParamsOptions(new ParamsOptions(WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE_MARKDOWN,
                        WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE_MARKDOWN, false))
                .setValue(WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE_TEXT)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();

        InputParam atMobilesParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_AT_MOBILES,
                        WechatTalkParamsConstants.WECHAT_TALK_AT_MOBILES)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();
        InputParam atUserIdsParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_AT_USERIDS,
                        WechatTalkParamsConstants.WECHAT_TALK_AT_USERIDS)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();
        RadioParam isAtAll = RadioParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_AT_ALL,
                        WechatTalkParamsConstants.WECHAT_TALK_AT_ALL)
                .addParamsOptions(new ParamsOptions(STRING_YES, STRING_TRUE, false))
                .addParamsOptions(new ParamsOptions(STRING_NO, STRING_FALSE, false))
                .setValue(STRING_FALSE)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();

        RadioParam isEnableProxy = RadioParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_PROXY_ENABLE,
                        WechatTalkParamsConstants.WECHAT_TALK_PROXY_ENABLE)
                .addParamsOptions(new ParamsOptions(STRING_YES, STRING_TRUE, false))
                .addParamsOptions(new ParamsOptions(STRING_NO, STRING_FALSE, false))
                .setValue(STRING_FALSE)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();
        InputParam proxyParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_PROXY,
                        WechatTalkParamsConstants.WECHAT_TALK_PROXY)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();

        InputParam portParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_PORT, WechatTalkParamsConstants.WECHAT_TALK_PORT)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();

        InputParam userParam = InputParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_USER, WechatTalkParamsConstants.WECHAT_TALK_USER)
                .addValidate(Validate.newBuilder()
                        .setRequired(false)
                        .build())
                .build();
        PasswordParam passwordParam = PasswordParam
                .newBuilder(WechatTalkParamsConstants.NAME_WECHAT_TALK_PASSWORD,
                        WechatTalkParamsConstants.WECHAT_TALK_PASSWORD)
                .setPlaceholder("if enable use authentication, you need input password")
                .build();

        return Arrays.asList(webHookParam, keywordParam, secretParam, msgTypeParam, atMobilesParam, atUserIdsParam,
                isAtAll, isEnableProxy, proxyParam, portParam, userParam, passwordParam);
    }

    @Override
    public AlertChannel create() {
        return new WechatTalkAlertChannel();
    }
}
