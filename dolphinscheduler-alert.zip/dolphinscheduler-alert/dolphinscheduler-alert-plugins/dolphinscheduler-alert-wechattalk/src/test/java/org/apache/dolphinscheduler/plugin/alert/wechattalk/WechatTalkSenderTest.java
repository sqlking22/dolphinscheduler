/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.dolphinscheduler.plugin.alert.wechattalk;

import org.apache.dolphinscheduler.alert.api.AlertResult;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class WechatTalkSenderTest {

    private static final Map<String, String> wechatTalkConfig = new HashMap<>();

    @Before
    public void initWechatTalkConfig() {

        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_KEYWORD, "keyword");
        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_WEB_HOOK, "url");
        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_MSG_TYPE,
                WechatTalkParamsConstants.WECHAT_TALK_MSG_TYPE_MARKDOWN);

        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_PROXY_ENABLE, "false");
        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_PASSWORD, "password");
        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_PORT, "9988");
        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_USER, "user1,user2");
    }

    @Test
    public void testSend() {
        WechatTalkSender wechatTalkSender = new WechatTalkSender(wechatTalkConfig);
        wechatTalkSender.sendWechatTalkMsg("keyWord+Welcome", "UTF-8");
        wechatTalkConfig.put(WechatTalkParamsConstants.NAME_WECHAT_TALK_PROXY_ENABLE, "true");
        wechatTalkSender = new WechatTalkSender(wechatTalkConfig);
        AlertResult alertResult = wechatTalkSender.sendWechatTalkMsg("title", "content test");
        Assert.assertEquals("false", alertResult.getStatus());
    }

}
